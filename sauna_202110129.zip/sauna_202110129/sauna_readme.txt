This Hubs scene is a dream space for sauna lovers. It is intended to be used for relaxation, communication, and various other purposes.

2021/02/03
This project is not limited to one scene in the heating room. Repeated expansions will reproduce the original facilities of the sauna facility. Cooling rooms, lobbies, etc. will be added in the future.

このHubsシーンは、サウナ好きの為の夢空間です。リラクゼーション、コミュニケーション、様々な用途で使われることを想定しています。

2021/02/03
このプロジェクトは、採暖室の１シーンに留まりません。増築を繰り返し、サウナ施設本来の設備を再現します。冷房室、ロビーなどが今後追加される予定です。